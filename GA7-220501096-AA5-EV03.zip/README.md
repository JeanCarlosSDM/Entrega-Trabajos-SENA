# API Productos

API REST sencilla desarrollada con **Node.js** y **Express**, para el proyecto formativo. Permite gestionar (consultar, crear, actualizar y eliminar) productos.

## 1. Requisitos
- Node.js instalado.
- Editor de código (Visual Studio Code).

## 2. Instalación
```
npm install
```

## 3. Ejecución
```
npm start
```
La API queda disponible en: `http://localhost:3000`

## 4. Documentación de los servicios

### Servicio 1: Consultar todos los productos
- **Método:** GET
- **Ruta:** `/api/productos`
- **Descripción:** Devuelve la lista completa de productos.
- **Respuesta ejemplo:**
```json
[
  { "id": 1, "nombre": "Teclado", "precio": 50000 },
  { "id": 2, "nombre": "Mouse", "precio": 30000 }
]
```

### Servicio 2: Consultar un producto por id
- **Método:** GET
- **Ruta:** `/api/productos/:id`
- **Descripción:** Devuelve un producto específico según su id.
- **Respuesta ejemplo:**
```json
{ "id": 1, "nombre": "Teclado", "precio": 50000 }
```
- **Error (si no existe):** `404` `{ "mensaje": "Producto no encontrado" }`

### Servicio 3: Crear un producto
- **Método:** POST
- **Ruta:** `/api/productos`
- **Cuerpo de la petición (JSON):**
```json
{ "nombre": "Monitor", "precio": 450000 }
```
- **Respuesta ejemplo:** `201 Created`
```json
{ "id": 3, "nombre": "Monitor", "precio": 450000 }
```

### Servicio 4: Actualizar un producto
- **Método:** PUT
- **Ruta:** `/api/productos/:id`
- **Cuerpo de la petición (JSON):**
```json
{ "nombre": "Monitor LED", "precio": 500000 }
```
- **Respuesta ejemplo:**
```json
{ "id": 3, "nombre": "Monitor LED", "precio": 500000 }
```

### Servicio 5: Eliminar un producto
- **Método:** DELETE
- **Ruta:** `/api/productos/:id`
- **Respuesta ejemplo:**
```json
{ "mensaje": "Producto eliminado" }
```

## 5. Interfaz web
Al entrar a `http://localhost:3000/` se muestra una página muy sencilla (HTML + JavaScript) que permite:
- Ver el listado de productos.
- Agregar un producto (nombre y precio).
- Eliminar un producto.

Esta interfaz solo consume los servicios de la API (no tiene lógica propia), y se encuentra en la carpeta `public/index.html`.

## 6. Pruebas de la API
Se recomienda usar **Postman** para probar cada servicio (crear una petición por cada método y ruta descrita arriba).

## 7. Control de versiones (Git)
Pasos para versionar el proyecto:
```
git init
git add .
git commit -m "Primera versión de la API de productos"
```
Si se desea subir a un repositorio remoto (ej. GitHub):
```
git remote add origin <URL_DEL_REPOSITORIO>
git branch -M main
git push -u origin main
```
