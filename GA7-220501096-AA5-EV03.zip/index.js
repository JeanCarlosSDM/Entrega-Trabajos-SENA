// index.js
// API REST simple para gestión de productos
// Tecnologías: Node.js + Express (ver componente "Construcción API")

const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json()); // Middleware para leer JSON en el cuerpo de las peticiones

// "Base de datos" en memoria (simple, sin motor externo)
let productos = [
  { id: 1, nombre: "Teclado", precio: 50000 },
  { id: 2, nombre: "Mouse", precio: 30000 }
];

// GET /api/productos -> Consultar todos los productos
app.get('/api/productos', (req, res) => {
  res.json(productos);
});

// GET /api/productos/:id -> Consultar un producto por id
app.get('/api/productos/:id', (req, res) => {
  const producto = productos.find(p => p.id === parseInt(req.params.id));
  if (!producto) return res.status(404).json({ mensaje: "Producto no encontrado" });
  res.json(producto);
});

// POST /api/productos -> Crear un nuevo producto
app.post('/api/productos', (req, res) => {
  const nuevoProducto = {
    id: productos.length + 1,
    nombre: req.body.nombre,
    precio: req.body.precio
  };
  productos.push(nuevoProducto);
  res.status(201).json(nuevoProducto);
});

// PUT /api/productos/:id -> Actualizar un producto existente
app.put('/api/productos/:id', (req, res) => {
  const producto = productos.find(p => p.id === parseInt(req.params.id));
  if (!producto) return res.status(404).json({ mensaje: "Producto no encontrado" });

  producto.nombre = req.body.nombre;
  producto.precio = req.body.precio;
  res.json(producto);
});

// DELETE /api/productos/:id -> Eliminar un producto
app.delete('/api/productos/:id', (req, res) => {
  const index = productos.findIndex(p => p.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ mensaje: "Producto no encontrado" });

  productos.splice(index, 1);
  res.json({ mensaje: "Producto eliminado" });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
