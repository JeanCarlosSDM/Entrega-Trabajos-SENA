package com.ejemplo.miprimeraapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mensaje emergente
        Toast.makeText(this, "¡Bienvenido!", Toast.LENGTH_LONG).show();
    }
}
