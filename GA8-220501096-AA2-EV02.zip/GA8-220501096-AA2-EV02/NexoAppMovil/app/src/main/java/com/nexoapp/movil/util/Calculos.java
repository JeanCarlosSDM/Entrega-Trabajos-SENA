package com.nexoapp.movil.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// Funciones sueltas que no dependen de Android, por eso se pueden probar fácil
public class Calculos {

    public static double calcularTotal(double precio, int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no es válido");
        }
        return precio * cantidad;
    }

    public static boolean nombreValido(String nombre) {
        return nombre != null && !nombre.trim().isEmpty();
    }

    public static boolean hayStock(int stock, int cantidad) {
        return cantidad > 0 && stock >= cantidad;
    }

    public static String formatoPesos(double valor) {
        return String.format(Locale.forLanguageTag("es-CO"), "$%,.0f", valor);
    }

    public static String fechaActual() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
    }
}
