package com.nexoapp.movil.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.nexoapp.movil.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteDao {
    private final DbHelper helper;

    public ClienteDao(Context context) {
        helper = DbHelper.getInstance(context);
    }

    public long insertar(Cliente cliente) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.insert("clientes", null, valores(cliente));
    }

    public List<Cliente> listar() {
        List<Cliente> lista = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, nombre, telefono FROM clientes ORDER BY nombre", null);
        while (c.moveToNext()) {
            lista.add(new Cliente(c.getInt(0), c.getString(1), c.getString(2)));
        }
        c.close();
        return lista;
    }

    public int actualizar(Cliente cliente) {
        SQLiteDatabase db = helper.getWritableDatabase();
        String[] args = {String.valueOf(cliente.getId())};
        return db.update("clientes", valores(cliente), "id = ?", args);
    }

    public int eliminar(int id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete("clientes", "id = ?", new String[]{String.valueOf(id)});
    }

    private ContentValues valores(Cliente cliente) {
        ContentValues valores = new ContentValues();
        valores.put("nombre", cliente.getNombre());
        valores.put("telefono", cliente.getTelefono());
        return valores;
    }
}
