package com.nexoapp.movil.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.nexoapp.movil.model.Producto;

import java.util.ArrayList;
import java.util.List;

public class ProductoDao {
    private final DbHelper helper;

    public ProductoDao(Context context) {
        helper = DbHelper.getInstance(context);
    }

    public long insertar(Producto producto) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.insert("productos", null, valores(producto));
    }

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, nombre, precio, stock FROM productos ORDER BY nombre", null);
        while (c.moveToNext()) {
            lista.add(new Producto(c.getInt(0), c.getString(1), c.getDouble(2), c.getInt(3)));
        }
        c.close();
        return lista;
    }

    public int actualizar(Producto producto) {
        SQLiteDatabase db = helper.getWritableDatabase();
        String[] args = {String.valueOf(producto.getId())};
        return db.update("productos", valores(producto), "id = ?", args);
    }

    public int eliminar(int id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete("productos", "id = ?", new String[]{String.valueOf(id)});
    }

    private ContentValues valores(Producto producto) {
        ContentValues valores = new ContentValues();
        valores.put("nombre", producto.getNombre());
        valores.put("precio", producto.getPrecio());
        valores.put("stock", producto.getStock());
        return valores;
    }
}
