package com.nexoapp.movil.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.nexoapp.movil.R;
import com.nexoapp.movil.data.ClienteDao;
import com.nexoapp.movil.data.ProductoDao;
import com.nexoapp.movil.data.VentaDao;
import com.nexoapp.movil.model.Cliente;
import com.nexoapp.movil.model.Producto;
import com.nexoapp.movil.util.Calculos;

import java.util.ArrayList;
import java.util.List;

public class VentasActivity extends AppCompatActivity {
    private Spinner spProducto;
    private Spinner spCliente;
    private EditText etCantidad;
    private TextView tvTotalVendido;
    private ProductoDao productoDao;
    private ClienteDao clienteDao;
    private VentaDao ventaDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);

        spProducto = findViewById(R.id.spProducto);
        spCliente = findViewById(R.id.spCliente);
        etCantidad = findViewById(R.id.etCantidad);
        tvTotalVendido = findViewById(R.id.tvTotalVendido);
        Button btnVender = findViewById(R.id.btnVender);
        productoDao = new ProductoDao(this);
        clienteDao = new ClienteDao(this);
        ventaDao = new VentaDao(this);

        btnVender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vender();
            }
        });
        cargarSpinners();
        mostrarTotal();
    }

    private void cargarSpinners() {
        List<Producto> productos = productoDao.listar();
        spProducto.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, productos));

        List<Cliente> clientes = new ArrayList<>();
        clientes.add(new Cliente(0, getString(R.string.sin_cliente), ""));
        clientes.addAll(clienteDao.listar());
        spCliente.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clientes));
    }

    private void vender() {
        Producto producto = (Producto) spProducto.getSelectedItem();
        int cantidad = leerCantidad();
        if (producto == null || cantidad <= 0) {
            Toast.makeText(this, R.string.msg_venta_invalida, Toast.LENGTH_SHORT).show();
            return;
        }
        Cliente cliente = (Cliente) spCliente.getSelectedItem();
        try {
            double total = ventaDao.registrar(producto.getId(), cliente.getId(), cantidad);
            String mensaje = getString(R.string.msg_venta_ok, Calculos.formatoPesos(total));
            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
            etCantidad.setText("");
            cargarSpinners();
            mostrarTotal();
        } catch (IllegalStateException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private int leerCantidad() {
        try {
            return Integer.parseInt(etCantidad.getText().toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void mostrarTotal() {
        String total = Calculos.formatoPesos(ventaDao.totalVendido());
        tvTotalVendido.setText(getString(R.string.total_vendido, total));
    }
}
