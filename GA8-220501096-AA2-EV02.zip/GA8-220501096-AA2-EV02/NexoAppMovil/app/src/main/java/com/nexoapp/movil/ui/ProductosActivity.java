package com.nexoapp.movil.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.nexoapp.movil.R;
import com.nexoapp.movil.data.ProductoDao;
import com.nexoapp.movil.model.Producto;
import com.nexoapp.movil.util.Calculos;

import java.util.List;

public class ProductosActivity extends AppCompatActivity {
    private EditText etNombre;
    private EditText etPrecio;
    private EditText etStock;
    private ListView lvProductos;
    private ProductoDao dao;
    private List<Producto> lista;
    private int seleccionado = 0; // 0 quiere decir que es un producto nuevo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);

        etNombre = findViewById(R.id.etNombre);
        etPrecio = findViewById(R.id.etPrecio);
        etStock = findViewById(R.id.etStock);
        lvProductos = findViewById(R.id.lvProductos);
        Button btnGuardar = findViewById(R.id.btnGuardar);
        dao = new ProductoDao(this);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardar();
            }
        });
        configurarLista();
        mostrarLista();
    }

    private void configurarLista() {
        lvProductos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Producto producto = lista.get(position);
                seleccionado = producto.getId();
                etNombre.setText(producto.getNombre());
                etPrecio.setText(String.valueOf(producto.getPrecio()));
                etStock.setText(String.valueOf(producto.getStock()));
            }
        });
        lvProductos.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                dao.eliminar(lista.get(position).getId());
                Toast.makeText(ProductosActivity.this, R.string.msg_borrado, Toast.LENGTH_SHORT).show();
                limpiar();
                mostrarLista();
                return true;
            }
        });
    }

    private void guardar() {
        String nombre = etNombre.getText().toString().trim();
        if (!Calculos.nombreValido(nombre)) {
            Toast.makeText(this, R.string.msg_nombre_vacio, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            double precio = Double.parseDouble(etPrecio.getText().toString());
            int stock = Integer.parseInt(etStock.getText().toString());
            Producto producto = new Producto(seleccionado, nombre, precio, stock);
            if (seleccionado == 0) {
                dao.insertar(producto);
            } else {
                dao.actualizar(producto);
            }
            limpiar();
            mostrarLista();
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.msg_numero_invalido, Toast.LENGTH_SHORT).show();
        }
    }

    private void limpiar() {
        seleccionado = 0;
        etNombre.setText("");
        etPrecio.setText("");
        etStock.setText("");
    }

    private void mostrarLista() {
        lista = dao.listar();
        lvProductos.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista));
    }
}
