package com.nexoapp.movil.model;

public class Cliente {
    private final int id;
    private final String nombre;
    private final String telefono;

    public Cliente(int id, String nombre, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    // El ArrayAdapter usa este texto para mostrar el cliente en la lista
    @Override
    public String toString() {
        if (telefono == null || telefono.isEmpty()) {
            return nombre;
        }
        return nombre + " - " + telefono;
    }
}
