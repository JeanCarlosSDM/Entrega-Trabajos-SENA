package com.nexoapp.movil.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.nexoapp.movil.R;

// Pantalla principal: solo tiene tres botones que abren cada módulo
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnClientes = findViewById(R.id.btnClientes);
        Button btnProductos = findViewById(R.id.btnProductos);
        Button btnVentas = findViewById(R.id.btnVentas);

        abrirAlTocar(btnClientes, ClientesActivity.class);
        abrirAlTocar(btnProductos, ProductosActivity.class);
        abrirAlTocar(btnVentas, VentasActivity.class);
    }

    // Intent explícito: va de esta pantalla a la que se le indique
    private void abrirAlTocar(Button boton, final Class<?> pantalla) {
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, pantalla));
            }
        });
    }
}
