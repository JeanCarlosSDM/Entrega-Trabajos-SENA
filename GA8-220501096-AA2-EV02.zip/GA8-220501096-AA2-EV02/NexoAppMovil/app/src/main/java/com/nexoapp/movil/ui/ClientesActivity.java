package com.nexoapp.movil.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.nexoapp.movil.R;
import com.nexoapp.movil.data.ClienteDao;
import com.nexoapp.movil.model.Cliente;
import com.nexoapp.movil.util.Calculos;

import java.util.List;

public class ClientesActivity extends AppCompatActivity {
    private EditText etNombre;
    private EditText etTelefono;
    private ListView lvClientes;
    private ClienteDao dao;
    private List<Cliente> lista;
    private int seleccionado = 0; // 0 quiere decir que es un cliente nuevo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes);

        etNombre = findViewById(R.id.etNombre);
        etTelefono = findViewById(R.id.etTelefono);
        lvClientes = findViewById(R.id.lvClientes);
        Button btnGuardar = findViewById(R.id.btnGuardar);
        dao = new ClienteDao(this);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardar();
            }
        });
        configurarLista();
        mostrarLista();
    }

    private void configurarLista() {
        lvClientes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cliente cliente = lista.get(position);
                seleccionado = cliente.getId();
                etNombre.setText(cliente.getNombre());
                etTelefono.setText(cliente.getTelefono());
            }
        });
        lvClientes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                dao.eliminar(lista.get(position).getId());
                Toast.makeText(ClientesActivity.this, R.string.msg_borrado, Toast.LENGTH_SHORT).show();
                limpiar();
                mostrarLista();
                return true;
            }
        });
    }

    private void guardar() {
        String nombre = etNombre.getText().toString().trim();
        if (!Calculos.nombreValido(nombre)) {
            Toast.makeText(this, R.string.msg_nombre_vacio, Toast.LENGTH_SHORT).show();
            return;
        }
        Cliente cliente = new Cliente(seleccionado, nombre, etTelefono.getText().toString().trim());
        if (seleccionado == 0) {
            dao.insertar(cliente);
        } else {
            dao.actualizar(cliente);
        }
        limpiar();
        mostrarLista();
    }

    private void limpiar() {
        seleccionado = 0;
        etNombre.setText("");
        etTelefono.setText("");
    }

    private void mostrarLista() {
        lista = dao.listar();
        lvClientes.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista));
    }
}
