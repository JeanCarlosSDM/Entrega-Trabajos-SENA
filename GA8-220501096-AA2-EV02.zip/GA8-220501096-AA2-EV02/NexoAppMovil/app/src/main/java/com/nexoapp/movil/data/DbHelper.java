package com.nexoapp.movil.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Crea la base de datos SQLite del celular. Se usa una sola instancia (singleton).
public class DbHelper extends SQLiteOpenHelper {
    private static final String NOMBRE = "nexoapp.db";
    private static final int VERSION = 1;
    private static DbHelper instancia;

    public static synchronized DbHelper getInstance(Context context) {
        if (instancia == null) {
            instancia = new DbHelper(context.getApplicationContext());
        }
        return instancia;
    }

    private DbHelper(Context context) {
        super(context, NOMBRE, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nombre TEXT NOT NULL, telefono TEXT)");
        db.execSQL("CREATE TABLE productos (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nombre TEXT NOT NULL, precio REAL NOT NULL, stock INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE ventas (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "producto_id INTEGER NOT NULL, cliente_id INTEGER, cantidad INTEGER NOT NULL, "
                + "total REAL NOT NULL, fecha TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versionVieja, int versionNueva) {
        db.execSQL("DROP TABLE IF EXISTS ventas");
        db.execSQL("DROP TABLE IF EXISTS productos");
        db.execSQL("DROP TABLE IF EXISTS clientes");
        onCreate(db);
    }
}
