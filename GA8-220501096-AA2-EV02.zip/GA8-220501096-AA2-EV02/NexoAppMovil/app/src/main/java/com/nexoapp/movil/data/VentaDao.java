package com.nexoapp.movil.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.nexoapp.movil.util.Calculos;

public class VentaDao {
    private final DbHelper helper;

    public VentaDao(Context context) {
        helper = DbHelper.getInstance(context);
    }

    // Registra la venta y descuenta el stock en una sola transacción. Devuelve el total.
    public double registrar(int productoId, int clienteId, int cantidad) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            double total = descontarStock(db, productoId, cantidad);
            guardarVenta(db, productoId, clienteId, cantidad, total);
            db.setTransactionSuccessful();
            return total;
        } finally {
            db.endTransaction();
        }
    }

    public double totalVendido() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT COALESCE(SUM(total), 0) FROM ventas", null);
        c.moveToFirst();
        double total = c.getDouble(0);
        c.close();
        return total;
    }

    private double descontarStock(SQLiteDatabase db, int productoId, int cantidad) {
        Cursor c = db.rawQuery("SELECT precio, stock FROM productos WHERE id = ?",
                new String[]{String.valueOf(productoId)});
        if (!c.moveToFirst()) {
            c.close();
            throw new IllegalStateException("El producto no existe");
        }
        double precio = c.getDouble(0);
        int stock = c.getInt(1);
        c.close();
        if (!Calculos.hayStock(stock, cantidad)) {
            throw new IllegalStateException("No hay stock suficiente");
        }
        db.execSQL("UPDATE productos SET stock = stock - ? WHERE id = ?", new Object[]{cantidad, productoId});
        return Calculos.calcularTotal(precio, cantidad);
    }

    private void guardarVenta(SQLiteDatabase db, int productoId, int clienteId, int cantidad, double total) {
        ContentValues valores = new ContentValues();
        valores.put("producto_id", productoId);
        if (clienteId > 0) {
            valores.put("cliente_id", clienteId);
        }
        valores.put("cantidad", cantidad);
        valores.put("total", total);
        valores.put("fecha", Calculos.fechaActual());
        db.insert("ventas", null, valores);
    }
}
