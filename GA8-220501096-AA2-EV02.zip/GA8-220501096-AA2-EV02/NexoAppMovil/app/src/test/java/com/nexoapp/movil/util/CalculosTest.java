package com.nexoapp.movil.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class CalculosTest {

    @Test
    public void calcularTotal_multiplicaPrecioPorCantidad() {
        assertEquals(24000.0, Calculos.calcularTotal(12000, 2), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void calcularTotal_fallaConCantidadCero() {
        Calculos.calcularTotal(12000, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void calcularTotal_fallaConPrecioNegativo() {
        Calculos.calcularTotal(-5, 1);
    }

    @Test
    public void nombreValido_rechazaVacioYNulo() {
        assertTrue(Calculos.nombreValido("Ana"));
        assertFalse(Calculos.nombreValido("   "));
        assertFalse(Calculos.nombreValido(null));
    }

    @Test
    public void hayStock_revisaLaCantidad() {
        assertTrue(Calculos.hayStock(10, 10));
        assertFalse(Calculos.hayStock(3, 5));
        assertFalse(Calculos.hayStock(10, 0));
    }
}
