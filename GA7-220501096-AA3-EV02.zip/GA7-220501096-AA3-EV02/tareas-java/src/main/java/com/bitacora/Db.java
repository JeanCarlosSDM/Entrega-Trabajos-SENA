package com.bitacora;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Maneja la conexión y la creación de tablas en la base de datos SQLite.
 * El archivo bitacora.db se crea automáticamente junto al programa.
 */
public class Db {

    private static final String URL = "jdbc:sqlite:bitacora.db";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() {
        String usersSql =
            "CREATE TABLE IF NOT EXISTS users (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "username TEXT UNIQUE NOT NULL," +
            "password TEXT NOT NULL," +
            "display_name TEXT," +
            "created_at INTEGER)";

        String tasksSql =
            "CREATE TABLE IF NOT EXISTS tasks (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "user_id INTEGER NOT NULL," +
            "title TEXT NOT NULL," +
            "done INTEGER DEFAULT 0," +
            "created_at INTEGER," +
            "FOREIGN KEY(user_id) REFERENCES users(id))";

        try (Connection conn = connect(); Statement st = conn.createStatement()) {
            st.execute(usersSql);
            st.execute(tasksSql);
            System.out.println("[OK] Base de datos lista: bitacora.db");
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo inicializar la base de datos", e);
        }
    }
}
