package com.bitacora;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {

    public static class UserRecord {
        public final int id;
        public final String displayName;
        public final long createdAt;

        public UserRecord(int id, String displayName, long createdAt) {
            this.id = id;
            this.displayName = displayName;
            this.createdAt = createdAt;
        }
    }

    public static boolean exists(String username) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE username = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public static void create(String username, String password, String displayName) throws SQLException {
        String sql = "INSERT INTO users (username, password, display_name, created_at) VALUES (?,?,?,?)";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, displayName);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        }
    }

    /** Busca un usuario validando usuario + contraseña (login). */
    public static UserRecord findForLogin(String username, String password) throws SQLException {
        String sql = "SELECT id, display_name, created_at FROM users WHERE username = ? AND password = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new UserRecord(rs.getInt("id"), rs.getString("display_name"), rs.getLong("created_at"));
                }
                return null;
            }
        }
    }

    /** Busca un usuario solo por su nombre de usuario (para resolver el token de sesión). */
    public static UserRecord findByUsername(String username) throws SQLException {
        String sql = "SELECT id, display_name, created_at FROM users WHERE username = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new UserRecord(rs.getInt("id"), rs.getString("display_name"), rs.getLong("created_at"));
                }
                return null;
            }
        }
    }
}
