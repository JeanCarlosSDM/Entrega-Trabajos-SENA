package com.bitacora;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;

/**
 * Servidor HTTP simple (sin frameworks externos) que expone una API REST
 * respaldada por SQLite, y sirve el frontend estático desde /public.
 */
public class App {

    static final int PORT = 4567;

    public static void main(String[] args) throws Exception {
        Db.init();

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/register", App::handleRegister);
        server.createContext("/api/login", App::handleLogin);
        server.createContext("/api/logout", App::handleLogout);
        server.createContext("/api/tasks", App::handleTasks);
        server.createContext("/", App::handleStatic);

        server.setExecutor(null);
        server.start();
        System.out.println("Servidor corriendo en http://localhost:" + PORT);
    }

    // ---------------- helpers ----------------

    private static JSONObject readJson(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            String body = new String(is.readAllBytes(), "UTF-8");
            return body.isBlank() ? new JSONObject() : new JSONObject(body);
        }
    }

    private static void sendJson(HttpExchange ex, int status, JSONObject json) throws IOException {
        byte[] bytes = json.toString().getBytes("UTF-8");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static void sendJsonArray(HttpExchange ex, int status, JSONArray arr) throws IOException {
        byte[] bytes = arr.toString().getBytes("UTF-8");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String tokenFrom(HttpExchange ex) {
        String header = ex.getRequestHeaders().getFirst("Authorization");
        if (header == null) return null;
        return header.replace("Bearer ", "").trim();
    }

    /** Devuelve el username si el token es válido, o responde 401 y devuelve null. */
    private static String requireAuth(HttpExchange ex) throws IOException {
        String token = tokenFrom(ex);
        String username = SessionManager.usernameFor(token);
        if (username == null) {
            sendJson(ex, 401, new JSONObject().put("error", "No autenticado."));
            return null;
        }
        return username;
    }

    // ---------------- handlers de autenticación ----------------

    private static void handleRegister(HttpExchange ex) throws IOException {
        if (!"POST".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(405, -1);
            return;
        }
        try {
            JSONObject body = readJson(ex);
            String username = body.optString("username", "").trim();
            String password = body.optString("password", "");
            String displayName = body.optString("displayName", username);
            if (displayName.isBlank()) displayName = username;

            if (username.isEmpty() || password.isEmpty()) {
                sendJson(ex, 400, new JSONObject().put("error", "Usuario y contraseña son obligatorios."));
                return;
            }
            if (UserDao.exists(username)) {
                sendJson(ex, 409, new JSONObject().put("error", "Ese usuario ya existe."));
                return;
            }
            UserDao.create(username, password, displayName);
            String token = SessionManager.createSession(username);
            sendJson(ex, 201, new JSONObject()
                    .put("token", token)
                    .put("username", username)
                    .put("displayName", displayName));
        } catch (SQLException e) {
            sendJson(ex, 500, new JSONObject().put("error", "Error de base de datos."));
        }
    }

    private static void handleLogin(HttpExchange ex) throws IOException {
        if (!"POST".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(405, -1);
            return;
        }
        try {
            JSONObject body = readJson(ex);
            String username = body.optString("username", "").trim();
            String password = body.optString("password", "");

            UserDao.UserRecord user = UserDao.findForLogin(username, password);
            if (user == null) {
                sendJson(ex, 401, new JSONObject().put("error", "Usuario o contraseña incorrectos."));
                return;
            }
            String token = SessionManager.createSession(username);
            sendJson(ex, 200, new JSONObject()
                    .put("token", token)
                    .put("username", username)
                    .put("displayName", user.displayName));
        } catch (SQLException e) {
            sendJson(ex, 500, new JSONObject().put("error", "Error de base de datos."));
        }
    }

    private static void handleLogout(HttpExchange ex) throws IOException {
        if (!"POST".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(405, -1);
            return;
        }
        SessionManager.invalidate(tokenFrom(ex));
        sendJson(ex, 200, new JSONObject().put("ok", true));
    }

    // ---------------- handler de tareas ----------------

    private static void handleTasks(HttpExchange ex) throws IOException {
        String username = requireAuth(ex);
        if (username == null) return;

        try {
            UserDao.UserRecord user = UserDao.findByUsername(username);
            if (user == null) {
                sendJson(ex, 401, new JSONObject().put("error", "Sesión inválida."));
                return;
            }

            String path = ex.getRequestURI().getPath(); // /api/tasks  ó  /api/tasks/5
            String[] parts = path.split("/");
            Integer taskId = null;
            if (parts.length > 3) {
                try {
                    taskId = Integer.parseInt(parts[3]);
                } catch (NumberFormatException ignored) { }
            }
            String method = ex.getRequestMethod();

            if (taskId == null && "GET".equals(method)) {
                sendJsonArray(ex, 200, TaskDao.listForUser(user.id));

            } else if (taskId == null && "POST".equals(method)) {
                JSONObject body = readJson(ex);
                String title = body.optString("title", "").trim();
                if (title.isEmpty()) {
                    sendJson(ex, 400, new JSONObject().put("error", "El título no puede estar vacío."));
                    return;
                }
                int id = TaskDao.create(user.id, title);
                sendJson(ex, 201, new JSONObject().put("id", id));

            } else if (taskId != null && "PUT".equals(method)) {
                if (!TaskDao.belongsToUser(taskId, user.id)) {
                    sendJson(ex, 404, new JSONObject().put("error", "Tarea no encontrada."));
                    return;
                }
                JSONObject body = readJson(ex);
                if (body.has("title")) TaskDao.updateTitle(taskId, body.getString("title"));
                if (body.has("done")) TaskDao.updateDone(taskId, body.getBoolean("done"));
                sendJson(ex, 200, new JSONObject().put("ok", true));

            } else if (taskId != null && "DELETE".equals(method)) {
                if (!TaskDao.belongsToUser(taskId, user.id)) {
                    sendJson(ex, 404, new JSONObject().put("error", "Tarea no encontrada."));
                    return;
                }
                TaskDao.delete(taskId);
                sendJson(ex, 200, new JSONObject().put("ok", true));

            } else {
                ex.sendResponseHeaders(405, -1);
            }
        } catch (SQLException e) {
            sendJson(ex, 500, new JSONObject().put("error", "Error de base de datos."));
        }
    }

    // ---------------- archivos estáticos (frontend) ----------------

    private static void handleStatic(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        if (path.equals("/")) path = "/index.html";

        Path base = Paths.get("public").normalize();
        Path filePath = Paths.get("public", path).normalize();

        if (!filePath.startsWith(base) || !Files.exists(filePath) || Files.isDirectory(filePath)) {
            ex.sendResponseHeaders(404, -1);
            ex.close();
            return;
        }

        byte[] bytes = Files.readAllBytes(filePath);
        String contentType = path.endsWith(".css") ? "text/css"
                : path.endsWith(".js") ? "application/javascript"
                : "text/html; charset=utf-8";
        ex.getResponseHeaders().add("Content-Type", contentType);
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }
}
