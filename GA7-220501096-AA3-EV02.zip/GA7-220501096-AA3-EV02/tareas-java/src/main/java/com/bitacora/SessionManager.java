package com.bitacora;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sesiones simples en memoria: token aleatorio -> username.
 * Se pierden si el servidor se reinicia (suficiente para un proyecto de práctica).
 */
public class SessionManager {

    private static final Map<String, String> tokenToUsername = new ConcurrentHashMap<>();
    private static final SecureRandom random = new SecureRandom();

    public static String createSession(String username) {
        String token = new BigInteger(130, random).toString(32);
        tokenToUsername.put(token, username);
        return token;
    }

    public static String usernameFor(String token) {
        return token == null ? null : tokenToUsername.get(token);
    }

    public static void invalidate(String token) {
        if (token != null) tokenToUsername.remove(token);
    }
}
