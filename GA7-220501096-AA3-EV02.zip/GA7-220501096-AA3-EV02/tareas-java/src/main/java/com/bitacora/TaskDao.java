package com.bitacora;

import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TaskDao {

    public static JSONArray listForUser(int userId) throws SQLException {
        JSONArray arr = new JSONArray();
        String sql = "SELECT id, title, done, created_at FROM tasks WHERE user_id = ? ORDER BY created_at ASC";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    JSONObject o = new JSONObject();
                    o.put("id", rs.getInt("id"));
                    o.put("title", rs.getString("title"));
                    o.put("done", rs.getInt("done") == 1);
                    o.put("createdAt", rs.getLong("created_at"));
                    arr.put(o);
                }
            }
        }
        return arr;
    }

    public static int create(int userId, String title) throws SQLException {
        String sql = "INSERT INTO tasks (user_id, title, done, created_at) VALUES (?,?,0,?)";
        try (Connection c = Db.connect();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId);
            ps.setString(2, title);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    public static boolean belongsToUser(int taskId, int userId) throws SQLException {
        String sql = "SELECT 1 FROM tasks WHERE id = ? AND user_id = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            ps.setInt(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public static void updateTitle(int taskId, String title) throws SQLException {
        String sql = "UPDATE tasks SET title = ? WHERE id = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setInt(2, taskId);
            ps.executeUpdate();
        }
    }

    public static void updateDone(int taskId, boolean done) throws SQLException {
        String sql = "UPDATE tasks SET done = ? WHERE id = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, done ? 1 : 0);
            ps.setInt(2, taskId);
            ps.executeUpdate();
        }
    }

    public static void delete(int taskId) throws SQLException {
        String sql = "DELETE FROM tasks WHERE id = ?";
        try (Connection c = Db.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            ps.executeUpdate();
        }
    }
}
