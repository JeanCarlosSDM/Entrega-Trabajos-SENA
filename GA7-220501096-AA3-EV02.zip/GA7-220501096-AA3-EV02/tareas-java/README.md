# Bitácora — Tareas con Java + SQLite

Proyecto de práctica: backend en Java (sin frameworks externos, solo el
`HttpServer` que trae el propio JDK) + SQLite vía JDBC, con un frontend
que consume la API por `fetch`.

## Requisitos

- JDK 17 o superior
- Maven (para descargar las dos dependencias: `sqlite-jdbc` y `org.json`,
  y empaquetar todo en un solo `.jar`)

En VS Code, con la extensión **Extension Pack for Java** ya tienes todo
lo necesario para abrir la carpeta y correrlo.

## Estructura

```
tareas-java/
├── pom.xml
├── public/
│   └── index.html          <- frontend (login, tareas, perfil, logout)
└── src/main/java/com/bitacora/
    ├── App.java             <- servidor HTTP + rutas de la API
    ├── Db.java               <- conexión y creación de tablas SQLite
    ├── UserDao.java           <- consultas SQL de usuarios
    ├── TaskDao.java           <- consultas SQL de tareas
    └── SessionManager.java    <- tokens de sesión en memoria
```

## Cómo correrlo

Desde la carpeta `tareas-java/`:

```bash
mvn clean package
java -jar target/tareas-java.jar
```

Vas a ver en consola:

```
[OK] Base de datos lista: bitacora.db
Servidor corriendo en http://localhost:4567
```

Abre **http://localhost:4567** en el navegador. Ahí puedes registrarte,
iniciar sesión, agregar/editar/eliminar tareas, ir al perfil y cerrar
sesión.

El archivo `bitacora.db` se crea automáticamente la primera vez que
corres el programa, en la misma carpeta desde donde lo ejecutas — esa
es tu base de datos SQL con las tablas `users` y `tasks`.

## Cómo ver los datos directamente en SQLite

Si quieres confirmar que los datos quedan en la base de datos (por
ejemplo para tu sustentación o entrega), con `sqlite3` instalado:

```bash
sqlite3 bitacora.db
sqlite> .tables
sqlite> SELECT * FROM users;
sqlite> SELECT * FROM tasks;
```

## API REST expuesta

| Método | Ruta                | Descripción                        | Requiere token |
|--------|---------------------|-------------------------------------|----------------|
| POST   | /api/register        | Crea un usuario                     | No             |
| POST   | /api/login            | Inicia sesión, devuelve token        | No             |
| POST   | /api/logout           | Invalida el token                    | Sí             |
| GET    | /api/tasks             | Lista las tareas del usuario         | Sí             |
| POST   | /api/tasks             | Crea una tarea (`{ "title": "..." }`)| Sí             |
| PUT    | /api/tasks/{id}         | Edita título y/o estado `done`        | Sí             |
| DELETE | /api/tasks/{id}         | Elimina una tarea                     | Sí             |

El token va en el header `Authorization: Bearer <token>`.

## Notas honestas sobre este proyecto

- Las sesiones viven en memoria: si reinicias el servidor, todos
  quedan deslogueados (normal para un ejercicio; en un proyecto real
  se guardarían en la propia base de datos o se usaría JWT).
- Las contraseñas se guardan en texto plano para mantener el ejemplo
  simple. Si tu entrega lo requiere, el siguiente paso natural es
  aplicar un hash (por ejemplo con `BCrypt`) antes de guardar y
  comparar contraseñas.
- Todo el SQL usa `PreparedStatement`, así que ya está protegido
  contra inyección SQL.
